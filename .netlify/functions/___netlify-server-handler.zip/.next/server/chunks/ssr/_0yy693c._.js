module.exports=[46058,(a,b,c)=>{"use strict";function d(a){if("function"!=typeof WeakMap)return null;var b=new WeakMap,c=new WeakMap;return(d=function(a){return a?c:b})(a)}c._=function(a,b){if(!b&&a&&a.__esModule)return a;if(null===a||"object"!=typeof a&&"function"!=typeof a)return{default:a};var c=d(b);if(c&&c.has(a))return c.get(a);var e={__proto__:null},f=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var g in a)if("default"!==g&&Object.prototype.hasOwnProperty.call(a,g)){var h=f?Object.getOwnPropertyDescriptor(a,g):null;h&&(h.get||h.set)?Object.defineProperty(e,g,h):e[g]=a[g]}return e.default=a,c&&c.set(a,e),e}},39118,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0});var d={DEFAULT_SEGMENT_KEY:function(){return l},NOT_FOUND_SEGMENT_KEY:function(){return m},PAGE_SEGMENT_KEY:function(){return k},addSearchParamsIfPageSegment:function(){return i},computeSelectedLayoutSegment:function(){return j},getSegmentValue:function(){return f},getSelectedLayoutSegmentPath:function(){return function a(b,c,d=!0,e=[]){let g;if(d)g=b[1][c];else{let a=b[1];g=a.children??Object.values(a)[0]}if(!g)return e;let h=f(g[0]);return!h||h.startsWith(k)?e:(e.push(h),a(g,c,!1,e))}},isGroupSegment:function(){return g},isParallelRouteSegment:function(){return h}};for(var e in d)Object.defineProperty(c,e,{enumerable:!0,get:d[e]});function f(a){return Array.isArray(a)?a[1]:a}function g(a){return"("===a[0]&&a.endsWith(")")}function h(a){return a.startsWith("@")&&"@children"!==a}function i(a,b){if(a.includes(k)){let a=JSON.stringify(b);return"{}"!==a?k+"?"+a:k}return a}function j(a,b){if(!a||0===a.length)return null;let c="children"===b?a[0]:a[a.length-1];return c===l?null:c}let k="__PAGE__",l="__DEFAULT__",m="/_not-found"},88644,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"InvariantError",{enumerable:!0,get:function(){return d}});class d extends Error{constructor(a,b){super(`Invariant: ${a.endsWith(".")?a:a+"."} This is a bug in Next.js.`,b),this.name="InvariantError"}}},54427,(a,b,c)=>{"use strict";function d(){let a,b,c=new Promise((c,d)=>{a=c,b=d});return{resolve:a,reject:b,promise:c}}Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"createPromiseWithResolvers",{enumerable:!0,get:function(){return d}})},6704,a=>{"use strict";let b,c;var d,e=a.i(72131);let f={data:""},g=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,h=/\/\*[^]*?\*\/|  +/g,i=/\n+/g,j=(a,b)=>{let c="",d="",e="";for(let f in a){let g=a[f];"@"==f[0]?"i"==f[1]?c=f+" "+g+";":d+="f"==f[1]?j(g,f):f+"{"+j(g,"k"==f[1]?"":b)+"}":"object"==typeof g?d+=j(g,b?b.replace(/([^,])+/g,a=>f.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,b=>/&/.test(b)?b.replace(/&/g,a):a?a+" "+b:b)):f):null!=g&&(f="-"==f[1]?f:f.replace(/[A-Z]/g,"-$&").toLowerCase(),e+=j.p?j.p(f,g):f+":"+g+";")}return c+(b&&e?b+"{"+e+"}":e)+d},k={},l=a=>{if("object"==typeof a){let b="";for(let c in a)b+=c+l(a[c]);return b}return a};function m(a){let b,c,d=this||{},e=a.call?a(d.p):a;return((a,b,c,d,e)=>{var f;let m=l(a),n=k[m]||(k[m]=(a=>{let b=0,c=11;for(;b<a.length;)c=101*c+a.charCodeAt(b++)>>>0;return"go"+c})(m));if(!k[n]){let b=m!==a?a:(a=>{let b,c,d=[{}];for(;b=g.exec(a.replace(h,""));)b[4]?d.shift():b[3]?(c=b[3].replace(i," ").trim(),d.unshift(d[0][c]=d[0][c]||{})):d[0][b[1]]=b[2].replace(i," ").trim();return d[0]})(a);k[n]=j(e?{["@keyframes "+n]:b}:b,c?"":"."+n)}let o=c&&k.g;return c&&(k.g=k[n]),f=k[n],o?b.data=b.data.replace(o,f):-1===b.data.indexOf(f)&&(b.data=d?f+b.data:b.data+f),n})(e.unshift?e.raw?(b=[].slice.call(arguments,1),c=d.p,e.reduce((a,d,e)=>{let f=b[e];if(f&&f.call){let a=f(c),b=a&&a.props&&a.props.className||/^go/.test(a)&&a;f=b?"."+b:a&&"object"==typeof a?a.props?"":j(a,""):!1===a?"":a}return a+d+(null==f?"":f)},"")):e.reduce((a,b)=>Object.assign(a,b&&b.call?b(d.p):b),{}):e,d.target||f,d.g,d.o,d.k)}m.bind({g:1});let n,o,p,q=m.bind({k:1});function r(a,b){let c=this||{};return function(){let d=arguments;function e(f,g){let h=Object.assign({},f),i=h.className||e.className;c.p=Object.assign({theme:o&&o()},h),c.o=/go\d/.test(i),h.className=m.apply(c,d)+(i?" "+i:""),b&&(h.ref=g);let j=a;return a[0]&&(j=h.as||a,delete h.as),p&&j[0]&&p(h),n(j,h)}return b?b(e):e}}var s=(a,b)=>"function"==typeof a?a(b):a,t=(b=0,()=>(++b).toString()),u="default",v=(a,b)=>{let{toastLimit:c}=a.settings;switch(b.type){case 0:return{...a,toasts:[b.toast,...a.toasts].slice(0,c)};case 1:return{...a,toasts:a.toasts.map(a=>a.id===b.toast.id?{...a,...b.toast}:a)};case 2:let{toast:d}=b;return v(a,{type:+!!a.toasts.find(a=>a.id===d.id),toast:d});case 3:let{toastId:e}=b;return{...a,toasts:a.toasts.map(a=>a.id===e||void 0===e?{...a,dismissed:!0,visible:!1}:a)};case 4:return void 0===b.toastId?{...a,toasts:[]}:{...a,toasts:a.toasts.filter(a=>a.id!==b.toastId)};case 5:return{...a,pausedAt:b.time};case 6:let f=b.time-(a.pausedAt||0);return{...a,pausedAt:void 0,toasts:a.toasts.map(a=>({...a,pauseDuration:a.pauseDuration+f}))}}},w=[],x={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},y={},z=(a,b=u)=>{y[b]=v(y[b]||x,a),w.forEach(([a,c])=>{a===b&&c(y[b])})},A=a=>Object.keys(y).forEach(b=>z(a,b)),B=(a=u)=>b=>{z(b,a)},C=a=>(b,c)=>{let d,e=((a,b="blank",c)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:b,ariaProps:{role:"status","aria-live":"polite"},message:a,pauseDuration:0,...c,id:(null==c?void 0:c.id)||t()}))(b,a,c);return B(e.toasterId||(d=e.id,Object.keys(y).find(a=>y[a].toasts.some(a=>a.id===d))))({type:2,toast:e}),e.id},D=(a,b)=>C("blank")(a,b);D.error=C("error"),D.success=C("success"),D.loading=C("loading"),D.custom=C("custom"),D.dismiss=(a,b)=>{let c={type:3,toastId:a};b?B(b)(c):A(c)},D.dismissAll=a=>D.dismiss(void 0,a),D.remove=(a,b)=>{let c={type:4,toastId:a};b?B(b)(c):A(c)},D.removeAll=a=>D.remove(void 0,a),D.promise=(a,b,c)=>{let d=D.loading(b.loading,{...c,...null==c?void 0:c.loading});return"function"==typeof a&&(a=a()),a.then(a=>{let e=b.success?s(b.success,a):void 0;return e?D.success(e,{id:d,...c,...null==c?void 0:c.success}):D.dismiss(d),a}).catch(a=>{let e=b.error?s(b.error,a):void 0;e?D.error(e,{id:d,...c,...null==c?void 0:c.error}):D.dismiss(d)}),a};var E=q`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,F=q`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,G=q`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,H=r("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${E} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${F} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${a=>a.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${G} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,I=q`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,J=r("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${a=>a.secondary||"#e0e0e0"};
  border-right-color: ${a=>a.primary||"#616161"};
  animation: ${I} 1s linear infinite;
`,K=q`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,L=q`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,M=r("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${K} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${L} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${a=>a.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,N=r("div")`
  position: absolute;
`,O=r("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,P=q`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Q=r("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${P} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,R=({toast:a})=>{let{icon:b,type:c,iconTheme:d}=a;return void 0!==b?"string"==typeof b?e.createElement(Q,null,b):b:"blank"===c?null:e.createElement(O,null,e.createElement(J,{...d}),"loading"!==c&&e.createElement(N,null,"error"===c?e.createElement(H,{...d}):e.createElement(M,{...d})))},S=r("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,T=r("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`;e.memo(({toast:a,position:b,style:d,children:f})=>{let g=a.height?((a,b)=>{let d=a.includes("top")?1:-1,[e,f]=c?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*d}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*d}%,-1px) scale(.6); opacity:0;}
`];return{animation:b?`${q(e)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${q(f)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(a.position||b||"top-center",a.visible):{opacity:0},h=e.createElement(R,{toast:a}),i=e.createElement(T,{...a.ariaProps},s(a.message,a));return e.createElement(S,{className:a.className,style:{...g,...d,...a.style}},"function"==typeof f?f({icon:h,message:i}):e.createElement(e.Fragment,null,h,i))}),d=e.createElement,j.p=void 0,n=d,o=void 0,p=void 0,m`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,a.s(["default",0,D],6704)},6769,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(50944),e=a.i(38246),f=a.i(36383);a.i(69387);var g=a.i(51384),h=a.i(1787),i=a.i(6704);a.s(["default",0,function({params:a}){let j=(0,d.useRouter)(),[k,l]=(0,c.useState)(!0),[m,n]=(0,c.useState)(null),[o,p]=(0,c.useState)({today:{online:0,offline:0,totalOnlineMinutes:0,totalOfflineMinutes:0},week:{online:0,offline:0,totalOnlineMinutes:0,totalOfflineMinutes:0},month:{online:0,offline:0,totalOnlineMinutes:0,totalOfflineMinutes:0}});(0,c.useEffect)(()=>{q()},[a.id]);let q=async()=>{try{let b=(0,g.doc)(f.db,"drivers",a.id),c=await (0,h.getDoc)(b);if(c.exists()){let a=c.data();n(a);let b=a.onlineHistory||[],d=a.offlineHistory||[];[...b.map(a=>({...a,status:"online"})),...d.map(a=>({...a,status:"offline"}))].sort((a,b)=>new Date(a.timestamp).getTime()-new Date(b.timestamp).getTime());let e=b.reduce((a,b)=>a+(b.duration||0),0),f=d.reduce((a,b)=>a+(b.duration||0),0),g={online:b.length,offline:d.length,totalOnlineMinutes:e,totalOfflineMinutes:f};p({today:g,week:{online:0,offline:0,totalOnlineMinutes:0,totalOfflineMinutes:0},month:{online:0,offline:0,totalOnlineMinutes:0,totalOfflineMinutes:0}})}else i.default.error("Driver not found"),j.push("/drivers")}catch(a){console.error("Error fetching driver activity:",a),i.default.error("Failed to load driver activity")}finally{l(!1)}},r=a=>{if(a<60)return`${a}m`;let b=Math.floor(a/60);return`${b}h ${a%60}m`};return k?(0,b.jsx)("div",{className:"flex items-center justify-center min-h-[60vh]",children:(0,b.jsx)("div",{className:"animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"})}):(0,b.jsxs)("div",{className:"space-y-6",children:[(0,b.jsxs)("div",{className:"flex items-center justify-between",children:[(0,b.jsxs)("div",{children:[(0,b.jsx)("h1",{className:"text-2xl font-bold text-gray-900",children:"Driver Activity"}),(0,b.jsxs)("p",{className:"text-sm text-gray-500",children:[m?.name," - Online/Offline Activity Tracking"]})]}),(0,b.jsxs)("div",{className:"flex space-x-3",children:[(0,b.jsxs)(e.default,{href:`/drivers/edit/${a.id}`,className:"text-sm text-blue-600 hover:text-blue-800 flex items-center space-x-1",children:[(0,b.jsx)("span",{children:"✏️"}),(0,b.jsx)("span",{children:"Edit Driver"})]}),(0,b.jsxs)(e.default,{href:"/drivers",className:"text-sm text-gray-500 hover:text-gray-700 flex items-center space-x-1",children:[(0,b.jsx)("span",{children:"←"}),(0,b.jsx)("span",{children:"Back to Drivers"})]})]})]}),(0,b.jsx)("div",{className:"bg-white rounded-xl shadow-sm p-6 border border-gray-100",children:(0,b.jsxs)("div",{className:"flex items-center justify-between",children:[(0,b.jsxs)("div",{className:"flex items-center space-x-4",children:[(0,b.jsx)("div",{className:`w-4 h-4 rounded-full ${m?.isOnline?"bg-green-500 animate-pulse":"bg-gray-400"}`}),(0,b.jsxs)("div",{children:[(0,b.jsx)("h2",{className:"text-lg font-semibold",children:m?.isOnline?"🟢 Online":"⚪ Offline"}),(0,b.jsxs)("p",{className:"text-sm text-gray-500",children:["Status: ",m?.status||"Unknown"]})]})]}),(0,b.jsxs)("div",{className:"text-right",children:[(0,b.jsx)("p",{className:"text-sm text-gray-500",children:"Last Update"}),(0,b.jsx)("p",{className:"text-sm font-medium",children:m?.lastUpdate?new Date(m.lastUpdate).toLocaleString():"Never"})]})]})}),(0,b.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6",children:[(0,b.jsxs)("div",{className:"bg-white rounded-xl shadow-sm p-6 border border-gray-100",children:[(0,b.jsx)("h3",{className:"text-sm font-medium text-gray-500 mb-4",children:"Today"}),(0,b.jsxs)("div",{className:"space-y-3",children:[(0,b.jsxs)("div",{className:"flex justify-between",children:[(0,b.jsx)("span",{className:"text-sm text-gray-600",children:"🟢 Online"}),(0,b.jsxs)("span",{className:"text-sm font-medium text-green-600",children:[o.today.online," times"]})]}),(0,b.jsxs)("div",{className:"flex justify-between",children:[(0,b.jsx)("span",{className:"text-sm text-gray-600",children:"⚪ Offline"}),(0,b.jsxs)("span",{className:"text-sm font-medium text-red-600",children:[o.today.offline," times"]})]}),(0,b.jsxs)("div",{className:"flex justify-between border-t pt-2",children:[(0,b.jsx)("span",{className:"text-sm font-medium text-gray-700",children:"Total Online"}),(0,b.jsx)("span",{className:"text-sm font-bold text-green-600",children:r(o.today.totalOnlineMinutes)})]}),(0,b.jsxs)("div",{className:"flex justify-between",children:[(0,b.jsx)("span",{className:"text-sm font-medium text-gray-700",children:"Total Offline"}),(0,b.jsx)("span",{className:"text-sm font-bold text-red-600",children:r(o.today.totalOfflineMinutes)})]})]})]}),(0,b.jsxs)("div",{className:"bg-white rounded-xl shadow-sm p-6 border border-gray-100",children:[(0,b.jsx)("h3",{className:"text-sm font-medium text-gray-500 mb-4",children:"This Week"}),(0,b.jsxs)("div",{className:"space-y-3",children:[(0,b.jsxs)("div",{className:"flex justify-between",children:[(0,b.jsx)("span",{className:"text-sm text-gray-600",children:"🟢 Online"}),(0,b.jsxs)("span",{className:"text-sm font-medium text-green-600",children:[o.week.online," times"]})]}),(0,b.jsxs)("div",{className:"flex justify-between",children:[(0,b.jsx)("span",{className:"text-sm text-gray-600",children:"⚪ Offline"}),(0,b.jsxs)("span",{className:"text-sm font-medium text-red-600",children:[o.week.offline," times"]})]}),(0,b.jsxs)("div",{className:"flex justify-between border-t pt-2",children:[(0,b.jsx)("span",{className:"text-sm font-medium text-gray-700",children:"Total Online"}),(0,b.jsx)("span",{className:"text-sm font-bold text-green-600",children:r(o.week.totalOnlineMinutes)})]}),(0,b.jsxs)("div",{className:"flex justify-between",children:[(0,b.jsx)("span",{className:"text-sm font-medium text-gray-700",children:"Total Offline"}),(0,b.jsx)("span",{className:"text-sm font-bold text-red-600",children:r(o.week.totalOfflineMinutes)})]})]})]}),(0,b.jsxs)("div",{className:"bg-white rounded-xl shadow-sm p-6 border border-gray-100",children:[(0,b.jsx)("h3",{className:"text-sm font-medium text-gray-500 mb-4",children:"This Month"}),(0,b.jsxs)("div",{className:"space-y-3",children:[(0,b.jsxs)("div",{className:"flex justify-between",children:[(0,b.jsx)("span",{className:"text-sm text-gray-600",children:"🟢 Online"}),(0,b.jsxs)("span",{className:"text-sm font-medium text-green-600",children:[o.month.online," times"]})]}),(0,b.jsxs)("div",{className:"flex justify-between",children:[(0,b.jsx)("span",{className:"text-sm text-gray-600",children:"⚪ Offline"}),(0,b.jsxs)("span",{className:"text-sm font-medium text-red-600",children:[o.month.offline," times"]})]}),(0,b.jsxs)("div",{className:"flex justify-between border-t pt-2",children:[(0,b.jsx)("span",{className:"text-sm font-medium text-gray-700",children:"Total Online"}),(0,b.jsx)("span",{className:"text-sm font-bold text-green-600",children:r(o.month.totalOnlineMinutes)})]}),(0,b.jsxs)("div",{className:"flex justify-between",children:[(0,b.jsx)("span",{className:"text-sm font-medium text-gray-700",children:"Total Offline"}),(0,b.jsx)("span",{className:"text-sm font-bold text-red-600",children:r(o.month.totalOfflineMinutes)})]})]})]})]}),(0,b.jsxs)("div",{className:"bg-white rounded-xl shadow-sm border border-gray-100",children:[(0,b.jsxs)("div",{className:"p-6 border-b border-gray-200",children:[(0,b.jsx)("h3",{className:"text-lg font-semibold text-gray-900",children:"Detailed Activity History"}),(0,b.jsx)("p",{className:"text-sm text-gray-500",children:"All online/offline events in chronological order"})]}),(0,b.jsx)("div",{className:"p-6",children:(0,b.jsxs)("div",{className:"max-h-96 overflow-y-auto",children:[[...m?.onlineHistory||[],...m?.offlineHistory||[]].sort((a,b)=>new Date(b.timestamp).getTime()-new Date(a.timestamp).getTime()).slice(0,50).map((a,c)=>(0,b.jsxs)("div",{className:"flex items-center justify-between py-3 border-b border-gray-100",children:[(0,b.jsxs)("div",{className:"flex items-center space-x-3",children:[(0,b.jsx)("span",{className:"online"===a.status?"text-green-500":"text-red-500",children:"online"===a.status?"🟢":"⚪"}),(0,b.jsx)("span",{className:"text-sm font-medium",children:"online"===a.status?"Went Online":"Went Offline"})]}),(0,b.jsxs)("div",{className:"text-sm text-gray-500",children:[a.date," at ",a.time]})]},c)),(!m?.onlineHistory||0===m.onlineHistory.length)&&(!m?.offlineHistory||0===m.offlineHistory.length)&&(0,b.jsx)("p",{className:"text-center text-gray-500 py-8",children:"No activity recorded yet"})]})})]}),(0,b.jsxs)("div",{className:"flex justify-end space-x-3",children:[(0,b.jsx)(e.default,{href:`/drivers/edit/${a.id}`,className:"px-4 py-2 text-sm font-medium text-white bg-blue-500 rounded-lg hover:bg-blue-600 transition",children:"Edit Driver"}),(0,b.jsx)(e.default,{href:"/drivers",className:"px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition",children:"Back to List"})]})]})}])}];

//# sourceMappingURL=_0yy693c._.js.map