module.exports=[52534,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fuel_update_page_actions_1i6lroo.js.map