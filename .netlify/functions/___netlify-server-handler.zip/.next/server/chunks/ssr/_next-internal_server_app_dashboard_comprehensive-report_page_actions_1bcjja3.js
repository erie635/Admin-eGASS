module.exports=[15865,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_comprehensive-report_page_actions_1bcjja3.js.map