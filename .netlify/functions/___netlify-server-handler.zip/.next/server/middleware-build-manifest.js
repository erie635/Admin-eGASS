globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/7y1ZO51i8yCEOHwcTjpF5/_buildManifest.js",
    "static/7y1ZO51i8yCEOHwcTjpF5/_ssgManifest.js",
    "static/7y1ZO51i8yCEOHwcTjpF5/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3_yjp8hbo33cx.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/0iec5q4ack_04.js",
    "static/chunks/11oof8oxnxiv9.js",
    "static/chunks/turbopack-0qhogr0ic4_hb.js"
  ]
};
