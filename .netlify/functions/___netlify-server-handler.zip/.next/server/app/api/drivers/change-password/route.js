var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/drivers/change-password/route.js")
R.c("server/chunks/[root-of-the-server]__1rle8p6._.js")
R.c("server/chunks/[root-of-the-server]__1h-kc_d._.js")
R.c("server/chunks/_next-internal_server_app_api_drivers_change-password_route_actions_0ra6smv.js")
R.m(34763)
module.exports=R.m(34763).exports
