module.exports=[46058,(a,b,c)=>{"use strict";function d(a){if("function"!=typeof WeakMap)return null;var b=new WeakMap,c=new WeakMap;return(d=function(a){return a?c:b})(a)}c._=function(a,b){if(!b&&a&&a.__esModule)return a;if(null===a||"object"!=typeof a&&"function"!=typeof a)return{default:a};var c=d(b);if(c&&c.has(a))return c.get(a);var e={__proto__:null},f=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var g in a)if("default"!==g&&Object.prototype.hasOwnProperty.call(a,g)){var h=f?Object.getOwnPropertyDescriptor(a,g):null;h&&(h.get||h.set)?Object.defineProperty(e,g,h):e[g]=a[g]}return e.default=a,c&&c.set(a,e),e}},88644,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"InvariantError",{enumerable:!0,get:function(){return d}});class d extends Error{constructor(a,b){super(`Invariant: ${a.endsWith(".")?a:a+"."} This is a bug in Next.js.`,b),this.name="InvariantError"}}},39118,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0});var d={DEFAULT_SEGMENT_KEY:function(){return l},NOT_FOUND_SEGMENT_KEY:function(){return m},PAGE_SEGMENT_KEY:function(){return k},addSearchParamsIfPageSegment:function(){return i},computeSelectedLayoutSegment:function(){return j},getSegmentValue:function(){return f},getSelectedLayoutSegmentPath:function(){return function a(b,c,d=!0,e=[]){let g;if(d)g=b[1][c];else{let a=b[1];g=a.children??Object.values(a)[0]}if(!g)return e;let h=f(g[0]);return!h||h.startsWith(k)?e:(e.push(h),a(g,c,!1,e))}},isGroupSegment:function(){return g},isParallelRouteSegment:function(){return h}};for(var e in d)Object.defineProperty(c,e,{enumerable:!0,get:d[e]});function f(a){return Array.isArray(a)?a[1]:a}function g(a){return"("===a[0]&&a.endsWith(")")}function h(a){return a.startsWith("@")&&"@children"!==a}function i(a,b){if(a.includes(k)){let a=JSON.stringify(b);return"{}"!==a?k+"?"+a:k}return a}function j(a,b){if(!a||0===a.length)return null;let c="children"===b?a[0]:a[a.length-1];return c===l?null:c}let k="__PAGE__",l="__DEFAULT__",m="/_not-found"},54427,(a,b,c)=>{"use strict";function d(){let a,b,c=new Promise((c,d)=>{a=c,b=d});return{resolve:a,reject:b,promise:c}}Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"createPromiseWithResolvers",{enumerable:!0,get:function(){return d}})},6704,a=>{"use strict";let b,c;var d,e=a.i(72131);let f={data:""},g=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,h=/\/\*[^]*?\*\/|  +/g,i=/\n+/g,j=(a,b)=>{let c="",d="",e="";for(let f in a){let g=a[f];"@"==f[0]?"i"==f[1]?c=f+" "+g+";":d+="f"==f[1]?j(g,f):f+"{"+j(g,"k"==f[1]?"":b)+"}":"object"==typeof g?d+=j(g,b?b.replace(/([^,])+/g,a=>f.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,b=>/&/.test(b)?b.replace(/&/g,a):a?a+" "+b:b)):f):null!=g&&(f="-"==f[1]?f:f.replace(/[A-Z]/g,"-$&").toLowerCase(),e+=j.p?j.p(f,g):f+":"+g+";")}return c+(b&&e?b+"{"+e+"}":e)+d},k={},l=a=>{if("object"==typeof a){let b="";for(let c in a)b+=c+l(a[c]);return b}return a};function m(a){let b,c,d=this||{},e=a.call?a(d.p):a;return((a,b,c,d,e)=>{var f;let m=l(a),n=k[m]||(k[m]=(a=>{let b=0,c=11;for(;b<a.length;)c=101*c+a.charCodeAt(b++)>>>0;return"go"+c})(m));if(!k[n]){let b=m!==a?a:(a=>{let b,c,d=[{}];for(;b=g.exec(a.replace(h,""));)b[4]?d.shift():b[3]?(c=b[3].replace(i," ").trim(),d.unshift(d[0][c]=d[0][c]||{})):d[0][b[1]]=b[2].replace(i," ").trim();return d[0]})(a);k[n]=j(e?{["@keyframes "+n]:b}:b,c?"":"."+n)}let o=c&&k.g;return c&&(k.g=k[n]),f=k[n],o?b.data=b.data.replace(o,f):-1===b.data.indexOf(f)&&(b.data=d?f+b.data:b.data+f),n})(e.unshift?e.raw?(b=[].slice.call(arguments,1),c=d.p,e.reduce((a,d,e)=>{let f=b[e];if(f&&f.call){let a=f(c),b=a&&a.props&&a.props.className||/^go/.test(a)&&a;f=b?"."+b:a&&"object"==typeof a?a.props?"":j(a,""):!1===a?"":a}return a+d+(null==f?"":f)},"")):e.reduce((a,b)=>Object.assign(a,b&&b.call?b(d.p):b),{}):e,d.target||f,d.g,d.o,d.k)}m.bind({g:1});let n,o,p,q=m.bind({k:1});function r(a,b){let c=this||{};return function(){let d=arguments;function e(f,g){let h=Object.assign({},f),i=h.className||e.className;c.p=Object.assign({theme:o&&o()},h),c.o=/go\d/.test(i),h.className=m.apply(c,d)+(i?" "+i:""),b&&(h.ref=g);let j=a;return a[0]&&(j=h.as||a,delete h.as),p&&j[0]&&p(h),n(j,h)}return b?b(e):e}}var s=(a,b)=>"function"==typeof a?a(b):a,t=(b=0,()=>(++b).toString()),u="default",v=(a,b)=>{let{toastLimit:c}=a.settings;switch(b.type){case 0:return{...a,toasts:[b.toast,...a.toasts].slice(0,c)};case 1:return{...a,toasts:a.toasts.map(a=>a.id===b.toast.id?{...a,...b.toast}:a)};case 2:let{toast:d}=b;return v(a,{type:+!!a.toasts.find(a=>a.id===d.id),toast:d});case 3:let{toastId:e}=b;return{...a,toasts:a.toasts.map(a=>a.id===e||void 0===e?{...a,dismissed:!0,visible:!1}:a)};case 4:return void 0===b.toastId?{...a,toasts:[]}:{...a,toasts:a.toasts.filter(a=>a.id!==b.toastId)};case 5:return{...a,pausedAt:b.time};case 6:let f=b.time-(a.pausedAt||0);return{...a,pausedAt:void 0,toasts:a.toasts.map(a=>({...a,pauseDuration:a.pauseDuration+f}))}}},w=[],x={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},y={},z=(a,b=u)=>{y[b]=v(y[b]||x,a),w.forEach(([a,c])=>{a===b&&c(y[b])})},A=a=>Object.keys(y).forEach(b=>z(a,b)),B=(a=u)=>b=>{z(b,a)},C=a=>(b,c)=>{let d,e=((a,b="blank",c)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:b,ariaProps:{role:"status","aria-live":"polite"},message:a,pauseDuration:0,...c,id:(null==c?void 0:c.id)||t()}))(b,a,c);return B(e.toasterId||(d=e.id,Object.keys(y).find(a=>y[a].toasts.some(a=>a.id===d))))({type:2,toast:e}),e.id},D=(a,b)=>C("blank")(a,b);D.error=C("error"),D.success=C("success"),D.loading=C("loading"),D.custom=C("custom"),D.dismiss=(a,b)=>{let c={type:3,toastId:a};b?B(b)(c):A(c)},D.dismissAll=a=>D.dismiss(void 0,a),D.remove=(a,b)=>{let c={type:4,toastId:a};b?B(b)(c):A(c)},D.removeAll=a=>D.remove(void 0,a),D.promise=(a,b,c)=>{let d=D.loading(b.loading,{...c,...null==c?void 0:c.loading});return"function"==typeof a&&(a=a()),a.then(a=>{let e=b.success?s(b.success,a):void 0;return e?D.success(e,{id:d,...c,...null==c?void 0:c.success}):D.dismiss(d),a}).catch(a=>{let e=b.error?s(b.error,a):void 0;e?D.error(e,{id:d,...c,...null==c?void 0:c.error}):D.dismiss(d)}),a};var E=q`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,F=q`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,G=q`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,H=r("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${E} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${F} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${a=>a.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${G} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,I=q`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,J=r("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${a=>a.secondary||"#e0e0e0"};
  border-right-color: ${a=>a.primary||"#616161"};
  animation: ${I} 1s linear infinite;
`,K=q`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,L=q`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,M=r("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${K} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${L} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${a=>a.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,N=r("div")`
  position: absolute;
`,O=r("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,P=q`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Q=r("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${P} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,R=({toast:a})=>{let{icon:b,type:c,iconTheme:d}=a;return void 0!==b?"string"==typeof b?e.createElement(Q,null,b):b:"blank"===c?null:e.createElement(O,null,e.createElement(J,{...d}),"loading"!==c&&e.createElement(N,null,"error"===c?e.createElement(H,{...d}):e.createElement(M,{...d})))},S=r("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,T=r("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`;e.memo(({toast:a,position:b,style:d,children:f})=>{let g=a.height?((a,b)=>{let d=a.includes("top")?1:-1,[e,f]=c?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*d}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*d}%,-1px) scale(.6); opacity:0;}
`];return{animation:b?`${q(e)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${q(f)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(a.position||b||"top-center",a.visible):{opacity:0},h=e.createElement(R,{toast:a}),i=e.createElement(T,{...a.ariaProps},s(a.message,a));return e.createElement(S,{className:a.className,style:{...g,...d,...a.style}},"function"==typeof f?f({icon:h,message:i}):e.createElement(e.Fragment,null,h,i))}),d=e.createElement,j.p=void 0,n=d,o=void 0,p=void 0,m`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,a.s(["default",0,D],6704)},44141,a=>{"use strict";var b=a.i(52617);a.s(["collection",()=>b.a_])},28807,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(36383);a.i(69387);var e=a.i(44141),f=a.i(51384),g=a.i(1787),h=a.i(6704),i=a.i(38246);let j=a=>{if(!a)return null;try{if("function"==typeof a?.toDate){let b=a.toDate();return b instanceof Date&&!isNaN(b.getTime())?b:null}if(a instanceof Date)return isNaN(a.getTime())?null:a;let b=new Date(a);if(isNaN(b.getTime()))return null;return b}catch(a){return console.error("Error converting date:",a),null}},k=a=>{if("number"==typeof a&&Number.isFinite(a))return a;if("string"==typeof a){let b=Number(a.replace(/,/g,"").trim());return Number.isFinite(b)?b:0}return 0};a.s(["default",0,function(){let a,[l,m]=(0,c.useState)([]),[n,o]=(0,c.useState)(!0),[p,q]=(0,c.useState)({totalRevenue:0,totalLitres:0,totalOrders:0}),[r,s]=(0,c.useState)("white"),[t,u]=(0,c.useState)(!1),[v,w]=(0,c.useState)([]),[x,y]=(0,c.useState)(""),[z,A]=(0,c.useState)(""),[B,C]=(0,c.useState)(!1),D=(0,c.useRef)(null);(0,c.useEffect)(()=>{(async()=>{let a=d.auth.currentUser;if(a)try{let b=await (0,g.getDoc)((0,f.doc)(d.db,"users",a.uid));if(b.exists()){let a=b.data();a.background&&s(a.background)}}catch(a){console.error("Error fetching user background:",a)}})()},[]),(0,c.useEffect)(()=>{o(!0);let a=(0,e.collection)(d.db,"drivers");return D.current=(0,g.onSnapshot)(a,a=>{let b=[];a.docs.forEach(a=>{let c=a.data();Array.isArray(c.salesHistory)&&c.salesHistory.length>0&&c.salesHistory.forEach(d=>{b.push({...d,driverId:a.id,driverName:c.name||d.driverName||"Unknown Driver"})})});let c=b.sort((a,b)=>{let c=j(a.date),d=j(b.date),e=c?c.getTime():0;return(d?d.getTime():0)-e}),d=c.reduce((a,b)=>a+k(b.totalAmount),0);q({totalRevenue:d,totalLitres:c.reduce((a,b)=>a+k(b.litresSold),0),totalOrders:c.length}),m(c),w(c),o(!1)},a=>{console.error("Error in real-time sales data listener:",a),h.default.error("Failed to load sales data"),o(!1)}),()=>{D.current&&(D.current(),D.current=null)}},[]);let E=()=>{C(!0);try{let a=[...l];if(x){let b=new Date(`${x}T00:00:00`);a=a.filter(a=>{let c=j(a.date);return!!c&&c.getTime()>=b.getTime()})}if(z){let b=new Date(`${z}T23:59:59.999`);a=a.filter(a=>{let c=j(a.date);return!!c&&c.getTime()<=b.getTime()})}a.sort((a,b)=>{let c=j(a.date),d=j(b.date),e=c?c.getTime():0;return(d?d.getTime():0)-e}),w(a),0===a.length?(0,h.default)("No sales found for the selected date range"):h.default.success(`Found ${a.length} sales transactions`)}catch(a){console.error("Error filtering sales:",a),h.default.error("Failed to filter sales")}finally{C(!1)}},F=(a=t?v:l,t?a:a.slice(0,10)),G=l.length>10,H=()=>{switch(r){case"dark":return"bg-gray-900 text-white";case"skyblue":return"bg-gradient-to-br from-blue-100 to-blue-300";case"gray":return"bg-gray-200";default:return"bg-gray-100"}},I=()=>{switch(r){case"dark":return"bg-gray-800/95 border-gray-700";case"skyblue":return"bg-white/90 backdrop-blur-sm shadow-lg";default:return"bg-white shadow-lg"}};return n?(0,b.jsx)("div",{className:`min-h-screen flex items-center justify-center ${H()}`,children:(0,b.jsx)("div",{className:"animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"})}):(0,b.jsx)("div",{className:`min-h-screen p-4 md:p-6 transition-colors duration-300 ${H()}`,children:(0,b.jsx)("div",{className:"max-w-7xl mx-auto",children:(0,b.jsxs)("div",{className:"space-y-6",children:[(0,b.jsxs)("div",{className:"flex items-center justify-between",children:[(0,b.jsxs)("div",{children:[(0,b.jsx)("h1",{className:"text-2xl font-bold",children:"Sales Report"}),(0,b.jsx)("p",{className:`text-sm mt-1 ${"dark"===r?"text-gray-400":"text-gray-500"}`,children:"View all sales transactions"})]}),(0,b.jsxs)(i.default,{href:"/reports",className:`text-sm ${"dark"===r?"text-gray-400 hover:text-gray-200":"text-gray-500 hover:text-gray-700"} flex items-center space-x-1`,children:[(0,b.jsx)("span",{children:"←"}),(0,b.jsx)("span",{children:"Back to Reports"})]})]}),(0,b.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6",children:[(0,b.jsxs)("div",{className:`rounded-xl shadow-lg p-6 border ${"dark"===r?"border-emerald-800":"border-emerald-200"} ${I()} bg-emerald-500 dark:bg-emerald-900 hover:bg-emerald-600 dark:hover:bg-emerald-800 transition-all duration-300`,children:[(0,b.jsx)("p",{className:"text-sm font-semibold uppercase tracking-wider text-emerald-100 dark:text-emerald-300",children:"Total Revenue"}),(0,b.jsxs)("p",{className:"text-3xl font-bold text-white dark:text-emerald-100 mt-1",children:["KES ",p.totalRevenue.toLocaleString()]})]}),(0,b.jsxs)("div",{className:`rounded-xl shadow-lg p-6 border ${"dark"===r?"border-sky-800":"border-sky-200"} ${I()} bg-sky-500 dark:bg-sky-900 hover:bg-sky-600 dark:hover:bg-sky-800 transition-all duration-300`,children:[(0,b.jsx)("p",{className:"text-sm font-semibold uppercase tracking-wider text-sky-100 dark:text-sky-300",children:"Total Litres Sold"}),(0,b.jsxs)("p",{className:"text-3xl font-bold text-white dark:text-sky-100 mt-1",children:[p.totalLitres.toLocaleString(),"L"]})]}),(0,b.jsxs)("div",{className:`rounded-xl shadow-lg p-6 border ${"dark"===r?"border-violet-800":"border-violet-200"} ${I()} bg-violet-500 dark:bg-violet-900 hover:bg-violet-600 dark:hover:bg-violet-800 transition-all duration-300`,children:[(0,b.jsx)("p",{className:"text-sm font-semibold uppercase tracking-wider text-violet-100 dark:text-violet-300",children:"Total Orders"}),(0,b.jsx)("p",{className:"text-3xl font-bold text-white dark:text-violet-100 mt-1",children:p.totalOrders})]})]}),(0,b.jsxs)("div",{className:`rounded-xl shadow-sm border ${"dark"===r?"border-gray-700":"border-gray-200"} ${I()}`,children:[(0,b.jsx)("div",{className:`p-6 border-b ${"dark"===r?"border-gray-700":"border-gray-200"}`,children:(0,b.jsxs)("div",{className:"flex items-center justify-between",children:[(0,b.jsxs)("h2",{className:`text-lg font-semibold ${"dark"===r?"text-white":"text-gray-900"}`,children:["Sales History",(0,b.jsxs)("span",{className:`text-sm font-normal ml-2 ${"dark"===r?"text-gray-400":"text-gray-500"}`,children:["(",t?v.length:Math.min(10,l.length)," ","of"," ",l.length," ","transactions)"]})]}),G&&(0,b.jsx)("button",{onClick:()=>{let a=!t;u(a),a&&(x||z?E():w(l))},className:"text-sm text-blue-600 hover:text-blue-800 font-medium transition",children:t?"Show Less":"See All Transactions"})]})}),t&&(0,b.jsx)("div",{className:`p-4 border-b ${"dark"===r?"border-gray-700 bg-gray-800/50":"border-gray-200 bg-gray-50"}`,children:(0,b.jsxs)("div",{className:"flex flex-wrap items-end gap-3",children:[(0,b.jsxs)("div",{children:[(0,b.jsx)("label",{className:`block text-xs font-medium ${"dark"===r?"text-gray-400":"text-gray-700"} mb-1`,children:"Date From"}),(0,b.jsx)("input",{type:"date",value:x,onChange:a=>y(a.target.value),className:`px-3 py-1.5 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${"dark"===r?"bg-gray-700 text-white border-gray-600":"bg-white border-gray-300"}`})]}),(0,b.jsxs)("div",{children:[(0,b.jsx)("label",{className:`block text-xs font-medium ${"dark"===r?"text-gray-400":"text-gray-700"} mb-1`,children:"Date To"}),(0,b.jsx)("input",{type:"date",value:z,onChange:a=>A(a.target.value),className:`px-3 py-1.5 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${"dark"===r?"bg-gray-700 text-white border-gray-600":"bg-white border-gray-300"}`})]}),(0,b.jsx)("button",{onClick:E,disabled:B||!x&&!z,className:`px-4 py-1.5 text-sm font-medium text-white rounded-lg transition ${B||!x&&!z?"bg-gray-400 cursor-not-allowed":"bg-blue-500 hover:bg-blue-600"}`,children:B?"Filtering...":"Filter"}),(x||z)&&(0,b.jsx)("button",{onClick:()=>{y(""),A(""),w(l),(0,h.default)("Date filter cleared")},className:`px-4 py-1.5 text-sm font-medium rounded-lg transition ${"dark"===r?"text-gray-300 bg-gray-700 hover:bg-gray-600":"text-gray-700 bg-gray-200 hover:bg-gray-300"}`,children:"Clear"})]})}),(0,b.jsx)("div",{className:"overflow-x-auto",children:(0,b.jsxs)("table",{className:"w-full",children:[(0,b.jsx)("thead",{className:"bg-red-900",children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{className:`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${"dark"===r?"text-gray-400":"text-gray-200"}`,children:"Date"}),(0,b.jsx)("th",{className:`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${"dark"===r?"text-gray-400":"text-gray-200"}`,children:"Driver"}),(0,b.jsx)("th",{className:`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${"dark"===r?"text-gray-400":"text-gray-200"}`,children:"Fuel"}),(0,b.jsx)("th",{className:`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${"dark"===r?"text-gray-400":"text-gray-200"}`,children:"Litres"}),(0,b.jsx)("th",{className:`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${"dark"===r?"text-gray-400":"text-gray-200"}`,children:"Amount"})]})}),(0,b.jsx)("tbody",{className:`divide-y ${"dark"===r?"divide-gray-700":"divide-gray-200"}`,children:0===F.length?(0,b.jsx)("tr",{children:(0,b.jsx)("td",{colSpan:5,className:`px-6 py-8 text-center ${"dark"===r?"text-gray-400":"text-gray-500"}`,children:t&&(x||z)?"No sales found for the selected date range":"No sales data found"})}):F.map((a,c)=>{let d=j(a.date),e=k(a.litresSold),f=k(a.totalAmount);return(0,b.jsxs)("tr",{className:"dark"===r?"hover:bg-gray-800/50":"hover:bg-gray-50",children:[(0,b.jsx)("td",{className:`px-6 py-4 whitespace-nowrap text-sm ${"dark"===r?"text-gray-400":"text-gray-500"}`,children:d?d.toLocaleDateString():"N/A"}),(0,b.jsx)("td",{className:`px-6 py-4 whitespace-nowrap text-sm ${"dark"===r?"text-white":"text-gray-900"}`,children:a.driverName||"N/A"}),(0,b.jsx)("td",{className:`px-6 py-4 whitespace-nowrap text-sm ${"dark"===r?"text-white":"text-gray-900"}`,children:a.fuelType||"N/A"}),(0,b.jsxs)("td",{className:`px-6 py-4 whitespace-nowrap text-sm ${"dark"===r?"text-white":"text-gray-900"}`,children:[e.toLocaleString(),"L"]}),(0,b.jsxs)("td",{className:`px-6 py-4 whitespace-nowrap text-sm font-medium ${"dark"===r?"text-white":"text-gray-900"}`,children:["KES ",f.toLocaleString()]})]},`${a.driverId||"driver"}-${a.date||c}-${c}`)})})]})})]})]})})})}])}];

//# sourceMappingURL=_011l_fn._.js.map