module.exports=[70726,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_drivers_change-password_route_actions_0ra6smv.js.map