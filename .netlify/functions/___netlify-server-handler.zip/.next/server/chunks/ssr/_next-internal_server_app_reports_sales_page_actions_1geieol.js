module.exports=[17912,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_reports_sales_page_actions_1geieol.js.map