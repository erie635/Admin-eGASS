module.exports=[46058,(a,b,c)=>{"use strict";function d(a){if("function"!=typeof WeakMap)return null;var b=new WeakMap,c=new WeakMap;return(d=function(a){return a?c:b})(a)}c._=function(a,b){if(!b&&a&&a.__esModule)return a;if(null===a||"object"!=typeof a&&"function"!=typeof a)return{default:a};var c=d(b);if(c&&c.has(a))return c.get(a);var e={__proto__:null},f=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var g in a)if("default"!==g&&Object.prototype.hasOwnProperty.call(a,g)){var h=f?Object.getOwnPropertyDescriptor(a,g):null;h&&(h.get||h.set)?Object.defineProperty(e,g,h):e[g]=a[g]}return e.default=a,c&&c.set(a,e),e}},39118,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0});var d={DEFAULT_SEGMENT_KEY:function(){return l},NOT_FOUND_SEGMENT_KEY:function(){return m},PAGE_SEGMENT_KEY:function(){return k},addSearchParamsIfPageSegment:function(){return i},computeSelectedLayoutSegment:function(){return j},getSegmentValue:function(){return f},getSelectedLayoutSegmentPath:function(){return function a(b,c,d=!0,e=[]){let g;if(d)g=b[1][c];else{let a=b[1];g=a.children??Object.values(a)[0]}if(!g)return e;let h=f(g[0]);return!h||h.startsWith(k)?e:(e.push(h),a(g,c,!1,e))}},isGroupSegment:function(){return g},isParallelRouteSegment:function(){return h}};for(var e in d)Object.defineProperty(c,e,{enumerable:!0,get:d[e]});function f(a){return Array.isArray(a)?a[1]:a}function g(a){return"("===a[0]&&a.endsWith(")")}function h(a){return a.startsWith("@")&&"@children"!==a}function i(a,b){if(a.includes(k)){let a=JSON.stringify(b);return"{}"!==a?k+"?"+a:k}return a}function j(a,b){if(!a||0===a.length)return null;let c="children"===b?a[0]:a[a.length-1];return c===l?null:c}let k="__PAGE__",l="__DEFAULT__",m="/_not-found"},88644,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"InvariantError",{enumerable:!0,get:function(){return d}});class d extends Error{constructor(a,b){super(`Invariant: ${a.endsWith(".")?a:a+"."} This is a bug in Next.js.`,b),this.name="InvariantError"}}},54427,(a,b,c)=>{"use strict";function d(){let a,b,c=new Promise((c,d)=>{a=c,b=d});return{resolve:a,reject:b,promise:c}}Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"createPromiseWithResolvers",{enumerable:!0,get:function(){return d}})},6704,a=>{"use strict";let b,c;var d,e=a.i(72131);let f={data:""},g=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,h=/\/\*[^]*?\*\/|  +/g,i=/\n+/g,j=(a,b)=>{let c="",d="",e="";for(let f in a){let g=a[f];"@"==f[0]?"i"==f[1]?c=f+" "+g+";":d+="f"==f[1]?j(g,f):f+"{"+j(g,"k"==f[1]?"":b)+"}":"object"==typeof g?d+=j(g,b?b.replace(/([^,])+/g,a=>f.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,b=>/&/.test(b)?b.replace(/&/g,a):a?a+" "+b:b)):f):null!=g&&(f="-"==f[1]?f:f.replace(/[A-Z]/g,"-$&").toLowerCase(),e+=j.p?j.p(f,g):f+":"+g+";")}return c+(b&&e?b+"{"+e+"}":e)+d},k={},l=a=>{if("object"==typeof a){let b="";for(let c in a)b+=c+l(a[c]);return b}return a};function m(a){let b,c,d=this||{},e=a.call?a(d.p):a;return((a,b,c,d,e)=>{var f;let m=l(a),n=k[m]||(k[m]=(a=>{let b=0,c=11;for(;b<a.length;)c=101*c+a.charCodeAt(b++)>>>0;return"go"+c})(m));if(!k[n]){let b=m!==a?a:(a=>{let b,c,d=[{}];for(;b=g.exec(a.replace(h,""));)b[4]?d.shift():b[3]?(c=b[3].replace(i," ").trim(),d.unshift(d[0][c]=d[0][c]||{})):d[0][b[1]]=b[2].replace(i," ").trim();return d[0]})(a);k[n]=j(e?{["@keyframes "+n]:b}:b,c?"":"."+n)}let o=c&&k.g;return c&&(k.g=k[n]),f=k[n],o?b.data=b.data.replace(o,f):-1===b.data.indexOf(f)&&(b.data=d?f+b.data:b.data+f),n})(e.unshift?e.raw?(b=[].slice.call(arguments,1),c=d.p,e.reduce((a,d,e)=>{let f=b[e];if(f&&f.call){let a=f(c),b=a&&a.props&&a.props.className||/^go/.test(a)&&a;f=b?"."+b:a&&"object"==typeof a?a.props?"":j(a,""):!1===a?"":a}return a+d+(null==f?"":f)},"")):e.reduce((a,b)=>Object.assign(a,b&&b.call?b(d.p):b),{}):e,d.target||f,d.g,d.o,d.k)}m.bind({g:1});let n,o,p,q=m.bind({k:1});function r(a,b){let c=this||{};return function(){let d=arguments;function e(f,g){let h=Object.assign({},f),i=h.className||e.className;c.p=Object.assign({theme:o&&o()},h),c.o=/go\d/.test(i),h.className=m.apply(c,d)+(i?" "+i:""),b&&(h.ref=g);let j=a;return a[0]&&(j=h.as||a,delete h.as),p&&j[0]&&p(h),n(j,h)}return b?b(e):e}}var s=(a,b)=>"function"==typeof a?a(b):a,t=(b=0,()=>(++b).toString()),u="default",v=(a,b)=>{let{toastLimit:c}=a.settings;switch(b.type){case 0:return{...a,toasts:[b.toast,...a.toasts].slice(0,c)};case 1:return{...a,toasts:a.toasts.map(a=>a.id===b.toast.id?{...a,...b.toast}:a)};case 2:let{toast:d}=b;return v(a,{type:+!!a.toasts.find(a=>a.id===d.id),toast:d});case 3:let{toastId:e}=b;return{...a,toasts:a.toasts.map(a=>a.id===e||void 0===e?{...a,dismissed:!0,visible:!1}:a)};case 4:return void 0===b.toastId?{...a,toasts:[]}:{...a,toasts:a.toasts.filter(a=>a.id!==b.toastId)};case 5:return{...a,pausedAt:b.time};case 6:let f=b.time-(a.pausedAt||0);return{...a,pausedAt:void 0,toasts:a.toasts.map(a=>({...a,pauseDuration:a.pauseDuration+f}))}}},w=[],x={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},y={},z=(a,b=u)=>{y[b]=v(y[b]||x,a),w.forEach(([a,c])=>{a===b&&c(y[b])})},A=a=>Object.keys(y).forEach(b=>z(a,b)),B=(a=u)=>b=>{z(b,a)},C=a=>(b,c)=>{let d,e=((a,b="blank",c)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:b,ariaProps:{role:"status","aria-live":"polite"},message:a,pauseDuration:0,...c,id:(null==c?void 0:c.id)||t()}))(b,a,c);return B(e.toasterId||(d=e.id,Object.keys(y).find(a=>y[a].toasts.some(a=>a.id===d))))({type:2,toast:e}),e.id},D=(a,b)=>C("blank")(a,b);D.error=C("error"),D.success=C("success"),D.loading=C("loading"),D.custom=C("custom"),D.dismiss=(a,b)=>{let c={type:3,toastId:a};b?B(b)(c):A(c)},D.dismissAll=a=>D.dismiss(void 0,a),D.remove=(a,b)=>{let c={type:4,toastId:a};b?B(b)(c):A(c)},D.removeAll=a=>D.remove(void 0,a),D.promise=(a,b,c)=>{let d=D.loading(b.loading,{...c,...null==c?void 0:c.loading});return"function"==typeof a&&(a=a()),a.then(a=>{let e=b.success?s(b.success,a):void 0;return e?D.success(e,{id:d,...c,...null==c?void 0:c.success}):D.dismiss(d),a}).catch(a=>{let e=b.error?s(b.error,a):void 0;e?D.error(e,{id:d,...c,...null==c?void 0:c.error}):D.dismiss(d)}),a};var E=q`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,F=q`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,G=q`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,H=r("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${E} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${F} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${a=>a.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${G} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,I=q`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,J=r("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${a=>a.secondary||"#e0e0e0"};
  border-right-color: ${a=>a.primary||"#616161"};
  animation: ${I} 1s linear infinite;
`,K=q`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,L=q`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,M=r("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${K} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${L} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${a=>a.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,N=r("div")`
  position: absolute;
`,O=r("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,P=q`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Q=r("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${P} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,R=({toast:a})=>{let{icon:b,type:c,iconTheme:d}=a;return void 0!==b?"string"==typeof b?e.createElement(Q,null,b):b:"blank"===c?null:e.createElement(O,null,e.createElement(J,{...d}),"loading"!==c&&e.createElement(N,null,"error"===c?e.createElement(H,{...d}):e.createElement(M,{...d})))},S=r("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,T=r("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`;e.memo(({toast:a,position:b,style:d,children:f})=>{let g=a.height?((a,b)=>{let d=a.includes("top")?1:-1,[e,f]=c?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*d}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*d}%,-1px) scale(.6); opacity:0;}
`];return{animation:b?`${q(e)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${q(f)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(a.position||b||"top-center",a.visible):{opacity:0},h=e.createElement(R,{toast:a}),i=e.createElement(T,{...a.ariaProps},s(a.message,a));return e.createElement(S,{className:a.className,style:{...g,...d,...a.style}},"function"==typeof f?f({icon:h,message:i}):e.createElement(e.Fragment,null,h,i))}),d=e.createElement,j.p=void 0,n=d,o=void 0,p=void 0,m`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,a.s(["default",0,D],6704)},44141,a=>{"use strict";var b=a.i(52617);a.s(["collection",()=>b.a_])},33411,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(50944),e=a.i(38246),f=a.i(36383);a.i(69387);var g=a.i(44141),h=a.i(51384),i=a.i(1787),j=a.i(6704);let k={Petrol:1e5,Diesel:1e5,Kerosene:1e5,"V-Power":1e5};a.s(["default",0,function(){let a=(0,d.useRouter)(),[l,m]=(0,c.useState)(!1),[n,o]=(0,c.useState)("white"),[p,q]=(0,c.useState)({supplier:"",fuelType:"Petrol",litres:"",costPerLitre:"",date:new Date().toISOString().split("T")[0]});(0,c.useEffect)(()=>{(async()=>{let a=f.auth.currentUser;if(a)try{let b=await (0,i.getDoc)((0,h.doc)(f.db,"users",a.uid));if(b.exists()){let a=b.data();a.background&&o(a.background)}}catch(a){console.error("Error fetching user background:",a)}})()},[]);let r=(0,c.useMemo)(()=>(parseFloat(p.litres)||0)*(parseFloat(p.costPerLitre)||0),[p.litres,p.costPerLitre]),s=(0,c.useCallback)(a=>{let{name:b,value:c}=a.target;q(a=>({...a,[b]:c}))},[]),t=(0,c.useCallback)(async b=>{b.preventDefault(),m(!0);try{let b=parseFloat(p.litres),c=parseFloat(p.costPerLitre);if(b<=0){j.default.error("Please enter a valid amount of litres"),m(!1);return}if(c<=0){j.default.error("Please enter a valid cost per litre"),m(!1);return}let d=(0,h.doc)(f.db,"company","fuelStock"),e=await (0,i.runTransaction)(f.db,async a=>{let e=await a.get(d),i={Petrol:0,Diesel:0,Kerosene:0,"V-Power":0},j=[];if(e.exists()){let a=e.data();i=a.stock||{Petrol:0,Diesel:0,Kerosene:0,"V-Power":0},j=a.activityLog||[]}let{currentAmount:l,newAmount:m,capacity:n}=((a,b,c)=>{let d=k[a]||0,e=c[a]||0;if(e>d)throw Error(`${a} tank contains invalid value (${e.toFixed(1)}L). Maximum allowed is ${d}L. Please fix the stock first.`);if(e>=d)throw Error(`${a} tank is FULL! Current: ${e.toFixed(1)}L out of ${d}L. Cannot import more fuel.`);let f=e+b;if(f>d){let c=d-e;throw Error(`Cannot import ${b}L! ${a} tank capacity is ${d}L. Only ${c.toFixed(1)}L space available.`)}return{currentAmount:e,newAmount:f,capacity:d,availableSpace:d-e}})(p.fuelType,b,i),o={...i,[p.fuelType]:m},q=[{fuelType:p.fuelType,amount:b,action:"add",actionType:"Fuel Import",reason:`Imported ${b}L ${p.fuelType} from ${p.supplier} at KES ${c.toFixed(2)}/L`,timestamp:new Date().toISOString(),date:new Date().toLocaleString(),previousTankAmount:l,newTankAmount:m,updatedBy:"Admin",supplier:p.supplier,costPerLitre:c,totalCost:r,importDate:p.date,priceInfo:`KES ${c.toFixed(2)}/L | Total: KES ${r.toFixed(2)}`,capacityInfo:`${m}/${n}L (${(m/n*100).toFixed(1)}%)`,pricePerLitre:c,costDisplay:`💰 KES ${c.toFixed(2)}/L | 💳 Total: KES ${r.toFixed(2)}`},...j].slice(0,100);a.update(d,{stock:o,activityLog:q,lastUpdated:new Date().toISOString()});let s=(0,h.doc)((0,g.collection)(f.db,"fuelImports"));return a.set(s,{...p,litres:b,costPerLitre:c,totalCost:r,createdAt:new Date().toISOString()}),{newAmount:m,capacity:n,currentAmount:l,parsedLitres:b}}),l=(await (0,i.getDocs)((0,g.collection)(f.db,"drivers"))).docs.map(a=>({id:a.id,...a.data()})).filter(a=>!0===a.isOnline||"available"===a.status);if(l.length>0){let a=e.parsedLitres/l.length,b=l.map(b=>{let c=(0,h.doc)(f.db,"drivers",b.id),d=b.remainingFuel||{},e=p.fuelType;return(0,i.updateDoc)(c,{[`remainingFuel.${e}`]:(d[e]||0)+a,fuelUpdatedAt:new Date().toISOString(),fuelHistory:[{type:"import",date:new Date().toISOString(),fuelType:e,litresAdded:a,supplier:p.supplier,costPerLitre:parseFloat(p.costPerLitre),totalCost:r,importDate:p.date,priceInfo:`KES ${parseFloat(p.costPerLitre).toFixed(2)}/L | Total: KES ${r.toFixed(2)}`},...b.fuelHistory||[]].slice(0,50)})});await Promise.all(b),j.default.success(`✅ ${e.parsedLitres}L of ${p.fuelType} distributed to ${l.length} active drivers!`,{duration:4e3,icon:"🚚"})}else(0,j.default)("⚠️ Fuel added to company stock but no active drivers to distribute to.",{duration:4e3,icon:"ℹ️"});let n=e.newAmount/e.capacity*100,o=n>90?"⚠️":n>80?"🟡":"✅";j.default.success(`${o} ${e.parsedLitres}L ${p.fuelType} imported successfully! Tank: ${e.newAmount.toFixed(1)}L (${n.toFixed(1)}% of capacity)`,{duration:4e3,icon:"⛽"}),j.default.success(`💰 Cost: KES ${parseFloat(p.costPerLitre).toFixed(2)}/L | Total: KES ${r.toFixed(2)}`,{duration:4e3,icon:"💳"}),a.push("/fuel")}catch(a){console.error("Error importing fuel:",a),j.default.error(a.message||"Failed to import fuel")}finally{m(!1)}},[p,r,a]);return(0,b.jsx)("div",{className:`p-4 md:p-6 transition-colors duration-300 ${(()=>{switch(n){case"dark":return"bg-gray-900 text-white min-h-screen";case"skyblue":return"bg-gradient-to-br from-blue-100 to-blue-300 min-h-screen";case"gray":return"bg-gray-200 min-h-screen";default:return"bg-gray-100 min-h-screen"}})()}`,children:(0,b.jsxs)("div",{className:"max-w-4xl mx-auto space-y-6",children:[(0,b.jsxs)("div",{className:"flex items-center justify-between",children:[(0,b.jsxs)("div",{children:[(0,b.jsx)("h1",{className:`text-2xl font-bold ${"dark"===n?"text-white":"text-gray-900"}`,children:" Import Fuel"}),(0,b.jsx)("p",{className:`text-sm ${"dark"===n?"text-gray-400":"text-gray-500"}`,children:"Import fuel from depot to system and distribute to active drivers"})]}),(0,b.jsxs)(e.default,{href:"/fuel",className:`text-sm ${"dark"===n?"text-gray-400 hover:text-gray-200":"text-gray-500 hover:text-gray-700"} flex items-center space-x-1`,children:[(0,b.jsx)("span",{children:"←"}),(0,b.jsx)("span",{children:"Back to Fuel"})]})]}),(0,b.jsx)("div",{className:`rounded-xl shadow-sm p-6 border ${"dark"===n?"border-gray-700":"border-gray-100"} ${(()=>{switch(n){case"dark":return"bg-gray-800/95 border-gray-700 text-white";case"skyblue":return"bg-white/90 backdrop-blur-sm shadow-lg";default:return"bg-white shadow-lg"}})()}`,children:(0,b.jsxs)("form",{onSubmit:t,className:"space-y-6 max-w-2xl",children:[(0,b.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:[(0,b.jsxs)("div",{children:[(0,b.jsx)("label",{className:`block text-sm font-medium ${"dark"===n?"text-gray-300":"text-gray-700"} mb-2`,children:"Supplier *"}),(0,b.jsx)("input",{type:"text",name:"supplier",required:!0,className:`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 ${"dark"===n?"bg-gray-700 text-white border-gray-600":"bg-white border-gray-300"}`,placeholder:"Supplier name",value:p.supplier,onChange:s})]}),(0,b.jsxs)("div",{children:[(0,b.jsx)("label",{className:`block text-sm font-medium ${"dark"===n?"text-gray-300":"text-gray-700"} mb-2`,children:"Fuel Type *"}),(0,b.jsxs)("select",{name:"fuelType",required:!0,className:`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 ${"dark"===n?"bg-gray-700 text-white border-gray-600":"bg-white border-gray-300"}`,value:p.fuelType,onChange:s,children:[(0,b.jsx)("option",{value:"Petrol",children:"Petrol"}),(0,b.jsx)("option",{value:"Diesel",children:"Diesel"}),(0,b.jsx)("option",{value:"Kerosene",children:"Kerosene"}),(0,b.jsx)("option",{value:"V-Power",children:"V-Power"})]})]}),(0,b.jsxs)("div",{children:[(0,b.jsx)("label",{className:`block text-sm font-medium ${"dark"===n?"text-gray-300":"text-gray-700"} mb-2`,children:"Litres *"}),(0,b.jsx)("input",{type:"number",name:"litres",required:!0,className:`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 ${"dark"===n?"bg-gray-700 text-white border-gray-600":"bg-white border-gray-300"}`,placeholder:"1000",step:"0.01",min:"0",value:p.litres,onChange:s})]}),(0,b.jsxs)("div",{children:[(0,b.jsx)("label",{className:`block text-sm font-medium ${"dark"===n?"text-gray-300":"text-gray-700"} mb-2`,children:"Cost per Litre (KES) *"}),(0,b.jsx)("input",{type:"number",name:"costPerLitre",required:!0,className:`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 ${"dark"===n?"bg-gray-700 text-white border-gray-600":"bg-white border-gray-300"}`,placeholder:"185",step:"0.01",min:"0",value:p.costPerLitre,onChange:s})]}),(0,b.jsxs)("div",{children:[(0,b.jsx)("label",{className:`block text-sm font-medium ${"dark"===n?"text-gray-300":"text-gray-700"} mb-2`,children:"Import Date"}),(0,b.jsx)("div",{className:`w-full px-4 py-2 border rounded-lg ${"dark"===n?"bg-gray-700 text-gray-400 border-gray-600":"bg-gray-100 text-gray-700 border-gray-300"}`,children:p.date}),(0,b.jsx)("p",{className:"text-xs mt-1 text-gray-400",children:"Date is automatically set to today"})]}),(0,b.jsx)("div",{className:"flex items-end",children:(0,b.jsxs)("div",{className:`p-3 rounded-lg border w-full ${"dark"===n?"bg-gray-700 border-gray-600":"bg-gray-50 border-gray-200"}`,children:[(0,b.jsx)("p",{className:`text-xs ${"dark"===n?"text-gray-400":"text-gray-500"}`,children:"Total Cost"}),(0,b.jsxs)("p",{className:"text-lg font-bold text-green-600",children:["KES ",r.toFixed(2)]})]})})]}),(0,b.jsx)("div",{className:"p-4 rounded-lg bg-cyan-700 text-white border border-blue-700",children:(0,b.jsxs)("p",{className:"text-sm",children:["• ",(0,b.jsx)("strong",{children:"Copyright © 2026 eGAS. All rights reserved."})]})}),(0,b.jsxs)("div",{className:"flex justify-end space-x-3 pt-6 border-t border-gray-200",children:[(0,b.jsx)(e.default,{href:"/fuel",className:`px-4 py-2 text-sm font-medium ${"dark"===n?"text-gray-300 bg-gray-700 hover:bg-gray-600":"text-gray-700 bg-gray-100 hover:bg-gray-200"} rounded-lg transition`,children:"Cancel"}),(0,b.jsx)("button",{type:"submit",disabled:l,className:"px-6 py-2 text-sm font-medium text-white bg-green-500 rounded-lg hover:bg-green-600 transition disabled:opacity-50 disabled:cursor-not-allowed",children:l?(0,b.jsxs)("span",{className:"flex items-center space-x-2",children:[(0,b.jsxs)("svg",{className:"animate-spin h-4 w-4 text-white",xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",children:[(0,b.jsx)("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4"}),(0,b.jsx)("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"})]}),(0,b.jsx)("span",{children:"Importing..."})]}):"Import Fuel"})]})]})})]})})}])}];

//# sourceMappingURL=_0asvwb4._.js.map