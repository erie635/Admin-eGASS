module.exports=[29302,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_feedback_page_actions_0y_4w5q.js.map