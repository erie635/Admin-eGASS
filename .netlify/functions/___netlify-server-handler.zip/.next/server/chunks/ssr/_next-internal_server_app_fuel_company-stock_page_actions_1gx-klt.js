module.exports=[95335,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fuel_company-stock_page_actions_1gx-klt.js.map