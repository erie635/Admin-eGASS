module.exports=[46058,(a,b,c)=>{"use strict";function d(a){if("function"!=typeof WeakMap)return null;var b=new WeakMap,c=new WeakMap;return(d=function(a){return a?c:b})(a)}c._=function(a,b){if(!b&&a&&a.__esModule)return a;if(null===a||"object"!=typeof a&&"function"!=typeof a)return{default:a};var c=d(b);if(c&&c.has(a))return c.get(a);var e={__proto__:null},f=Object.defineProperty&&Object.getOwnPropertyDescriptor;for(var g in a)if("default"!==g&&Object.prototype.hasOwnProperty.call(a,g)){var h=f?Object.getOwnPropertyDescriptor(a,g):null;h&&(h.get||h.set)?Object.defineProperty(e,g,h):e[g]=a[g]}return e.default=a,c&&c.set(a,e),e}},88644,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"InvariantError",{enumerable:!0,get:function(){return d}});class d extends Error{constructor(a,b){super(`Invariant: ${a.endsWith(".")?a:a+"."} This is a bug in Next.js.`,b),this.name="InvariantError"}}},39118,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0});var d={DEFAULT_SEGMENT_KEY:function(){return l},NOT_FOUND_SEGMENT_KEY:function(){return m},PAGE_SEGMENT_KEY:function(){return k},addSearchParamsIfPageSegment:function(){return i},computeSelectedLayoutSegment:function(){return j},getSegmentValue:function(){return f},getSelectedLayoutSegmentPath:function(){return function a(b,c,d=!0,e=[]){let g;if(d)g=b[1][c];else{let a=b[1];g=a.children??Object.values(a)[0]}if(!g)return e;let h=f(g[0]);return!h||h.startsWith(k)?e:(e.push(h),a(g,c,!1,e))}},isGroupSegment:function(){return g},isParallelRouteSegment:function(){return h}};for(var e in d)Object.defineProperty(c,e,{enumerable:!0,get:d[e]});function f(a){return Array.isArray(a)?a[1]:a}function g(a){return"("===a[0]&&a.endsWith(")")}function h(a){return a.startsWith("@")&&"@children"!==a}function i(a,b){if(a.includes(k)){let a=JSON.stringify(b);return"{}"!==a?k+"?"+a:k}return a}function j(a,b){if(!a||0===a.length)return null;let c="children"===b?a[0]:a[a.length-1];return c===l?null:c}let k="__PAGE__",l="__DEFAULT__",m="/_not-found"},54427,(a,b,c)=>{"use strict";function d(){let a,b,c=new Promise((c,d)=>{a=c,b=d});return{resolve:a,reject:b,promise:c}}Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"createPromiseWithResolvers",{enumerable:!0,get:function(){return d}})},6704,a=>{"use strict";let b,c;var d,e=a.i(72131);let f={data:""},g=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,h=/\/\*[^]*?\*\/|  +/g,i=/\n+/g,j=(a,b)=>{let c="",d="",e="";for(let f in a){let g=a[f];"@"==f[0]?"i"==f[1]?c=f+" "+g+";":d+="f"==f[1]?j(g,f):f+"{"+j(g,"k"==f[1]?"":b)+"}":"object"==typeof g?d+=j(g,b?b.replace(/([^,])+/g,a=>f.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,b=>/&/.test(b)?b.replace(/&/g,a):a?a+" "+b:b)):f):null!=g&&(f="-"==f[1]?f:f.replace(/[A-Z]/g,"-$&").toLowerCase(),e+=j.p?j.p(f,g):f+":"+g+";")}return c+(b&&e?b+"{"+e+"}":e)+d},k={},l=a=>{if("object"==typeof a){let b="";for(let c in a)b+=c+l(a[c]);return b}return a};function m(a){let b,c,d=this||{},e=a.call?a(d.p):a;return((a,b,c,d,e)=>{var f;let m=l(a),n=k[m]||(k[m]=(a=>{let b=0,c=11;for(;b<a.length;)c=101*c+a.charCodeAt(b++)>>>0;return"go"+c})(m));if(!k[n]){let b=m!==a?a:(a=>{let b,c,d=[{}];for(;b=g.exec(a.replace(h,""));)b[4]?d.shift():b[3]?(c=b[3].replace(i," ").trim(),d.unshift(d[0][c]=d[0][c]||{})):d[0][b[1]]=b[2].replace(i," ").trim();return d[0]})(a);k[n]=j(e?{["@keyframes "+n]:b}:b,c?"":"."+n)}let o=c&&k.g;return c&&(k.g=k[n]),f=k[n],o?b.data=b.data.replace(o,f):-1===b.data.indexOf(f)&&(b.data=d?f+b.data:b.data+f),n})(e.unshift?e.raw?(b=[].slice.call(arguments,1),c=d.p,e.reduce((a,d,e)=>{let f=b[e];if(f&&f.call){let a=f(c),b=a&&a.props&&a.props.className||/^go/.test(a)&&a;f=b?"."+b:a&&"object"==typeof a?a.props?"":j(a,""):!1===a?"":a}return a+d+(null==f?"":f)},"")):e.reduce((a,b)=>Object.assign(a,b&&b.call?b(d.p):b),{}):e,d.target||f,d.g,d.o,d.k)}m.bind({g:1});let n,o,p,q=m.bind({k:1});function r(a,b){let c=this||{};return function(){let d=arguments;function e(f,g){let h=Object.assign({},f),i=h.className||e.className;c.p=Object.assign({theme:o&&o()},h),c.o=/go\d/.test(i),h.className=m.apply(c,d)+(i?" "+i:""),b&&(h.ref=g);let j=a;return a[0]&&(j=h.as||a,delete h.as),p&&j[0]&&p(h),n(j,h)}return b?b(e):e}}var s=(a,b)=>"function"==typeof a?a(b):a,t=(b=0,()=>(++b).toString()),u="default",v=(a,b)=>{let{toastLimit:c}=a.settings;switch(b.type){case 0:return{...a,toasts:[b.toast,...a.toasts].slice(0,c)};case 1:return{...a,toasts:a.toasts.map(a=>a.id===b.toast.id?{...a,...b.toast}:a)};case 2:let{toast:d}=b;return v(a,{type:+!!a.toasts.find(a=>a.id===d.id),toast:d});case 3:let{toastId:e}=b;return{...a,toasts:a.toasts.map(a=>a.id===e||void 0===e?{...a,dismissed:!0,visible:!1}:a)};case 4:return void 0===b.toastId?{...a,toasts:[]}:{...a,toasts:a.toasts.filter(a=>a.id!==b.toastId)};case 5:return{...a,pausedAt:b.time};case 6:let f=b.time-(a.pausedAt||0);return{...a,pausedAt:void 0,toasts:a.toasts.map(a=>({...a,pauseDuration:a.pauseDuration+f}))}}},w=[],x={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},y={},z=(a,b=u)=>{y[b]=v(y[b]||x,a),w.forEach(([a,c])=>{a===b&&c(y[b])})},A=a=>Object.keys(y).forEach(b=>z(a,b)),B=(a=u)=>b=>{z(b,a)},C=a=>(b,c)=>{let d,e=((a,b="blank",c)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:b,ariaProps:{role:"status","aria-live":"polite"},message:a,pauseDuration:0,...c,id:(null==c?void 0:c.id)||t()}))(b,a,c);return B(e.toasterId||(d=e.id,Object.keys(y).find(a=>y[a].toasts.some(a=>a.id===d))))({type:2,toast:e}),e.id},D=(a,b)=>C("blank")(a,b);D.error=C("error"),D.success=C("success"),D.loading=C("loading"),D.custom=C("custom"),D.dismiss=(a,b)=>{let c={type:3,toastId:a};b?B(b)(c):A(c)},D.dismissAll=a=>D.dismiss(void 0,a),D.remove=(a,b)=>{let c={type:4,toastId:a};b?B(b)(c):A(c)},D.removeAll=a=>D.remove(void 0,a),D.promise=(a,b,c)=>{let d=D.loading(b.loading,{...c,...null==c?void 0:c.loading});return"function"==typeof a&&(a=a()),a.then(a=>{let e=b.success?s(b.success,a):void 0;return e?D.success(e,{id:d,...c,...null==c?void 0:c.success}):D.dismiss(d),a}).catch(a=>{let e=b.error?s(b.error,a):void 0;e?D.error(e,{id:d,...c,...null==c?void 0:c.error}):D.dismiss(d)}),a};var E=q`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,F=q`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,G=q`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,H=r("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${E} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${F} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${a=>a.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${G} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,I=q`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,J=r("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${a=>a.secondary||"#e0e0e0"};
  border-right-color: ${a=>a.primary||"#616161"};
  animation: ${I} 1s linear infinite;
`,K=q`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,L=q`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,M=r("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${a=>a.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${K} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${L} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${a=>a.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,N=r("div")`
  position: absolute;
`,O=r("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,P=q`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Q=r("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${P} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,R=({toast:a})=>{let{icon:b,type:c,iconTheme:d}=a;return void 0!==b?"string"==typeof b?e.createElement(Q,null,b):b:"blank"===c?null:e.createElement(O,null,e.createElement(J,{...d}),"loading"!==c&&e.createElement(N,null,"error"===c?e.createElement(H,{...d}):e.createElement(M,{...d})))},S=r("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,T=r("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`;e.memo(({toast:a,position:b,style:d,children:f})=>{let g=a.height?((a,b)=>{let d=a.includes("top")?1:-1,[e,f]=c?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[`
0% {transform: translate3d(0,${-200*d}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${-150*d}%,-1px) scale(.6); opacity:0;}
`];return{animation:b?`${q(e)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${q(f)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(a.position||b||"top-center",a.visible):{opacity:0},h=e.createElement(R,{toast:a}),i=e.createElement(T,{...a.ariaProps},s(a.message,a));return e.createElement(S,{className:a.className,style:{...g,...d,...a.style}},"function"==typeof f?f({icon:h,message:i}):e.createElement(e.Fragment,null,h,i))}),d=e.createElement,j.p=void 0,n=d,o=void 0,p=void 0,m`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,a.s(["default",0,D],6704)},44141,a=>{"use strict";var b=a.i(52617);a.s(["collection",()=>b.a_])},4326,a=>{"use strict";var b=a.i(52617);a.s(["serverTimestamp",()=>b.bd])},28764,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(36383);a.i(69387);var e=a.i(44141),f=a.i(1787),g=a.i(51384),h=a.i(4326),i=a.i(38246),j=a.i(6704);a.s(["default",0,function(){let[a,k]=(0,c.useState)([]),[l,m]=(0,c.useState)(!0),[n,o]=(0,c.useState)(""),[p,q]=(0,c.useState)(!1),[r,s]=(0,c.useState)("white");(0,c.useEffect)(()=>{(async()=>{let a=d.auth.currentUser;if(a)try{let b=await (0,f.getDoc)((0,g.doc)(d.db,"users",a.uid));if(b.exists()){let a=b.data();a.background&&s(a.background)}}catch(a){console.error("Error fetching user background:",a)}})()},[]);let t=()=>{switch(r){case"dark":return"bg-gray-900 text-white";case"skyblue":return"bg-gradient-to-br from-blue-100 to-blue-300";case"gray":return"bg-gray-200";default:return"bg-gray-100"}},u=a=>null==a||0===a?"0L":`${a.toFixed(2)}L`,v=async a=>{try{let b=new Date().toISOString().split("T")[0],c=`${a.id}_${b}`,e=(0,g.doc)(d.db,"driverDailyActivity",c),i=a.isOnline??!1,j={driverId:a.id,driverName:a.name||"Unknown",numberPlate:a.numberPlate||"",date:b,lastUpdated:(0,h.serverTimestamp)(),isOnline:i,status:a.status||"unknown"};if(i)a.onlineSince||(j.onlineStart=(0,h.serverTimestamp)(),j.totalMinutes=0,j.totalHours=0),j.lastOnlineTime=(0,h.serverTimestamp)(),j.offlineStart=null,j.lastOfflineTime=null;else if(a.offlineSince||(j.offlineStart=(0,h.serverTimestamp)()),j.lastOfflineTime=(0,h.serverTimestamp)(),j.onlineStart=null,j.lastOnlineTime=null,a.onlineSince){let b=a.onlineSince instanceof Date?a.onlineSince:new Date(a.onlineSince),c=new Date().getTime()-b.getTime(),d=Math.floor(c/6e4),e=Math.floor(d/60),f=d%60;j.totalMinutes=d,j.totalHours=e,j.totalMinutesDisplay=f,j.lastOnlineTime=(0,h.serverTimestamp)()}await (0,f.setDoc)(e,j,{merge:!0});let k=(0,g.doc)(d.db,"drivers",a.id);await (0,f.updateDoc)(k,{dailyActivityId:c,todayStartTime:i?(0,h.serverTimestamp)():null,lastStatusChange:(0,h.serverTimestamp)()})}catch(a){console.error("Error updating daily activity:",a)}};(0,c.useEffect)(()=>{let a=(0,f.onSnapshot)((0,e.collection)(d.db,"drivers"),async a=>{try{let b=a.docs.map(a=>{let b=a.data();return{id:a.id,...b,lastSeen:b.lastSeen?.toDate?.()||b.lastSeen||null,onlineSince:b.onlineSince?.toDate?.()||b.onlineSince||null,offlineSince:b.offlineSince?.toDate?.()||b.offlineSince||null,lastStatusChange:b.lastStatusChange?.toDate?.()||b.lastStatusChange||null,todayStartTime:b.todayStartTime?.toDate?.()||b.todayStartTime||null,isOnline:b.isOnline??!1,remainingFuel:b.remainingFuel||{}}}),c=b.map(a=>{let{duration:b,statusTime:c,todayHours:d}=(a=>{let b=new Date,c="",d="",e="";if(a.onlineSince){let c=a.onlineSince instanceof Date?a.onlineSince:new Date(a.onlineSince),d=b.getTime()-c.getTime(),f=Math.floor(d/36e5),g=Math.floor(d%36e5/6e4);e=`${f}h ${g}m`}else e=void 0!==a.todayTotalHours?`${a.todayTotalHours}h ${a.todayTotalMinutes||0}m`:"0h 0m";if(a.isOnline&&a.onlineSince){let e=a.onlineSince instanceof Date?a.onlineSince:new Date(a.onlineSince),f=b.getTime()-e.getTime(),g=Math.floor(f/36e5),h=Math.floor(f%36e5/6e4);c=`${g>0?g+"h ":""}${h}m online`,d=`Since ${e.toLocaleTimeString()}`}else if(!a.isOnline&&a.offlineSince){let e=a.offlineSince instanceof Date?a.offlineSince:new Date(a.offlineSince),f=b.getTime()-e.getTime(),g=Math.floor(f/36e5),h=Math.floor(f%36e5/6e4);c=`${g>0?g+"h ":""}${h}m offline`,d=`Since ${e.toLocaleTimeString()}`}else if(a.lastSeen){let e=a.lastSeen instanceof Date?a.lastSeen:new Date(a.lastSeen),f=Math.floor((b.getTime()-e.getTime())/6e4);c=`Last seen ${f}m ago`,d=`At ${e.toLocaleTimeString()}`}else c="Status unknown",d="No timestamp";return{duration:c,statusTime:d,todayHours:e}})(a);return{...a,duration:b,statusTime:c,todayHours:d}});k(c),m(!1),q(!0),b.length>0&&Promise.all(b.map(a=>v(a))).catch(a=>console.error("Error updating daily activities:",a))}catch(a){console.error("Error processing drivers:",a),j.default.error("Failed to load drivers"),m(!1)}},a=>{console.error("Error fetching drivers:",a),j.default.error("Failed to load drivers"),m(!1)});return()=>a()},[]);let w=async(a,b)=>{if(confirm(`Are you sure you want to delete "${b}"?`))try{await (0,f.deleteDoc)((0,g.doc)(d.db,"drivers",a)),j.default.success("Driver deleted successfully")}catch(a){console.error("Error deleting driver:",a),j.default.error("Failed to delete driver")}},x=a.filter(a=>a.name?.toLowerCase().includes(n.toLowerCase())||a.email?.toLowerCase().includes(n.toLowerCase())||a.phone?.includes(n)||a.numberPlate?.toLowerCase().includes(n.toLowerCase()));return l?(0,b.jsx)("div",{className:`min-h-screen flex items-center justify-center ${t()}`,children:(0,b.jsx)("div",{className:"animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"})}):(0,b.jsx)("div",{className:`min-h-screen p-4 md:p-6 transition-colors duration-300 ${t()}`,children:(0,b.jsxs)("div",{className:"max-w-7xl mx-auto space-y-6",children:[(0,b.jsxs)("div",{className:"flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4",children:[(0,b.jsxs)("div",{children:[(0,b.jsx)("h1",{className:"text-2xl font-bold",children:"Drivers"}),(0,b.jsx)("p",{className:`text-sm mt-1 ${"dark"===r?"text-gray-400":"text-gray-500"}`,children:"Manage all drivers in the system"})]}),(0,b.jsx)("div",{className:"flex flex-wrap gap-2",children:(0,b.jsxs)(i.default,{href:"/drivers/add",className:"bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition flex items-center space-x-2",children:[(0,b.jsx)("span",{children:"+"}),(0,b.jsx)("span",{children:"Add Driver"})]})})]}),(0,b.jsx)("div",{className:"rounded-xl shadow-sm p-4 border bg-cyan-700 border-gray-200",children:(0,b.jsx)("input",{type:"text",placeholder:"Search drivers by name, email, phone or plate number...",value:n,onChange:a=>o(a.target.value),className:"w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 bg-gray-200 border-gray-300"})}),(0,b.jsxs)("div",{className:`rounded-xl shadow-sm border ${"dark"===r?"border-gray-700":"border-gray-100"} ${(()=>{switch(r){case"dark":return"bg-gray-800/95 border-gray-700";case"skyblue":return"bg-white/90 backdrop-blur-sm shadow-lg";default:return"bg-white shadow-lg"}})()}`,children:[(0,b.jsxs)("div",{className:`p-6 border-b ${"dark"===r?"border-gray-700":"border-gray-200"} flex justify-between items-center`,children:[(0,b.jsx)("h2",{className:`text-lg font-semibold ${"dark"===r?"text-white":"text-gray-900"}`,children:"All Drivers"}),(0,b.jsxs)("span",{className:`text-sm ${"dark"===r?"text-gray-400":"text-gray-500"}`,children:[x.length," drivers"]})]}),(0,b.jsx)("div",{className:"overflow-x-auto",children:(0,b.jsxs)("table",{className:"w-full",children:[(0,b.jsx)("thead",{className:"bg-red-900",children:(0,b.jsxs)("tr",{children:[(0,b.jsx)("th",{className:`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${"dark"===r?"text-gray-400":"text-gray-200"}`,children:"Name"}),(0,b.jsx)("th",{className:`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${"dark"===r?"text-gray-400":"text-gray-200"}`,children:"Email"}),(0,b.jsx)("th",{className:`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${"dark"===r?"text-gray-400":"text-gray-200"}`,children:"Phone"}),(0,b.jsx)("th",{className:`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${"dark"===r?"text-gray-400":"text-gray-200"}`,children:"Vehicle"}),(0,b.jsx)("th",{className:`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${"dark"===r?"text-gray-400":"text-gray-200"}`,children:"Fuel"}),(0,b.jsx)("th",{className:`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${"dark"===r?"text-gray-400":"text-gray-200"}`,children:"Status"}),(0,b.jsx)("th",{className:`px-6 py-3 text-left text-xs font-medium uppercase tracking-wider ${"dark"===r?"text-gray-400":"text-gray-200"}`,children:"Actions"})]})}),(0,b.jsx)("tbody",{className:`divide-y ${"dark"===r?"divide-gray-700":"divide-gray-200"}`,children:0===x.length?(0,b.jsx)("tr",{children:(0,b.jsx)("td",{colSpan:7,className:`px-6 py-8 text-center ${"dark"===r?"text-gray-400":"text-gray-500"}`,children:n?"No drivers match your search":'No drivers found. Click "Add Driver" to create one.'})}):x.map(a=>(0,b.jsxs)("tr",{className:"dark"===r?"hover:bg-gray-800/50":"hover:bg-gray-50",children:[(0,b.jsx)("td",{className:"px-6 py-4 whitespace-nowrap",children:(0,b.jsxs)("div",{className:"flex items-center",children:[(0,b.jsx)("div",{className:"w-8 h-8 rounded-full bg-green-100 flex items-center justify-center text-green-600 font-semibold text-sm",children:a.name?.charAt(0)||"?"}),(0,b.jsxs)("div",{className:"ml-3",children:[(0,b.jsx)("div",{className:`text-sm font-medium ${"dark"===r?"text-white":"text-gray-900"}`,children:a.name||"N/A"}),(0,b.jsx)("div",{className:`text-xs ${"dark"===r?"text-gray-400":"text-gray-500"}`,children:a.numberPlate||"No plate"})]})]})}),(0,b.jsx)("td",{className:`px-6 py-4 whitespace-nowrap text-sm ${"dark"===r?"text-gray-300":"text-gray-500"}`,children:a.email||"N/A"}),(0,b.jsx)("td",{className:`px-6 py-4 whitespace-nowrap text-sm ${"dark"===r?"text-gray-300":"text-gray-500"}`,children:a.phone||"N/A"}),(0,b.jsx)("td",{className:`px-6 py-4 whitespace-nowrap text-sm ${"dark"===r?"text-gray-300":"text-gray-500"}`,children:a.vehicleType||"N/A"}),(0,b.jsx)("td",{className:"px-6 py-4 whitespace-nowrap",children:(0,b.jsxs)("div",{className:"flex flex-col space-y-0.5",children:[a.remainingFuel?.Petrol!==void 0&&(0,b.jsxs)("span",{className:"text-xs font-medium text-blue-600",children:["⛽"," ",u(a.remainingFuel.Petrol)," ","Petrol"]}),a.remainingFuel?.Diesel!==void 0&&(0,b.jsxs)("span",{className:"text-xs font-medium text-green-600",children:["⛽"," ",u(a.remainingFuel.Diesel)," ","Diesel"]}),a.remainingFuel?.["V-Power"]!==void 0&&(0,b.jsxs)("span",{className:"text-xs font-medium text-purple-600",children:["⛽"," ",u(a.remainingFuel["V-Power"])," ","V-Power"]}),a.remainingFuel?.Kerosene!==void 0&&(0,b.jsxs)("span",{className:"text-xs font-medium text-orange-600",children:["⛽"," ",u(a.remainingFuel.Kerosene)," ","Kerosene"]}),!a.remainingFuel?.Petrol&&!a.remainingFuel?.Diesel&&!a.remainingFuel?.["V-Power"]&&!a.remainingFuel?.Kerosene&&(0,b.jsx)("span",{className:"text-xs text-gray-400",children:"No fuel data"})]})}),(0,b.jsxs)("td",{className:"px-6 py-4 whitespace-nowrap",children:[(0,b.jsx)("span",{className:`px-2 py-1 text-xs font-semibold rounded-full ${a.isOnline?"bg-green-100 text-green-800":"bg-gray-100 text-gray-800"}`,children:a.isOnline?"🟢 Active":"⚪ Inactive"}),a.status&&(0,b.jsx)("span",{className:`ml-2 px-2 py-1 text-xs font-semibold rounded-full ${"available"===a.status?"bg-blue-100 text-blue-800":"busy"===a.status?"bg-red-100 text-red-800":"on_break"===a.status?"bg-yellow-100 text-yellow-800":"bg-gray-100 text-gray-800"}`,children:a.status.replace("_"," ")})]}),(0,b.jsxs)("td",{className:"px-6 py-4 whitespace-nowrap text-sm",children:[(0,b.jsx)(i.default,{href:`/drivers/edit/${a.id}`,className:"text-blue-600 hover:text-blue-800 mr-3 font-medium",children:"Edit"}),(0,b.jsx)("button",{onClick:()=>w(a.id,a.name||"Driver"),className:"text-red-600 hover:text-red-800 font-medium",children:"Delete"})]})]},a.id))})]})})]})]})})}])}];

//# sourceMappingURL=_01dqc-u._.js.map