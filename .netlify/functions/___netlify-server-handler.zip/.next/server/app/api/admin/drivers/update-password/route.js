var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/drivers/update-password/route.js")
R.c("server/chunks/[root-of-the-server]__18y6jmd._.js")
R.c("server/chunks/[root-of-the-server]__1h-kc_d._.js")
R.c("server/chunks/1oeh_server_app_api_admin_drivers_update-password_route_actions_102_ci_.js")
R.m(85487)
module.exports=R.m(85487).exports
