var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/drivers/create-account/route.js")
R.c("server/chunks/[root-of-the-server]__0ifu42x._.js")
R.c("server/chunks/[root-of-the-server]__1h-kc_d._.js")
R.c("server/chunks/_next-internal_server_app_api_drivers_create-account_route_actions_0nusenk.js")
R.m(2596)
module.exports=R.m(2596).exports
