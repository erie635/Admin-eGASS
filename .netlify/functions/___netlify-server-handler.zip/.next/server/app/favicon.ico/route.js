var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_1hsuqpg._.js")
R.c("server/chunks/[root-of-the-server]__1h-kc_d._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1n41rqb.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_0g2jjls.js")
R.m(6218)
module.exports=R.m(6218).exports
