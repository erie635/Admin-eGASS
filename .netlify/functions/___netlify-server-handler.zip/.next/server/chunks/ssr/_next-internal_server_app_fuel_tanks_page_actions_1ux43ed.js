module.exports=[55877,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fuel_tanks_page_actions_1ux43ed.js.map